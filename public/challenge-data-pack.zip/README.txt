FIRST FIRE · NASA PSI challenge archive
Acquired 2026-11-15T04:54:03.807875+00:00. The 15 core investigations contain 16 original experimental CSVs
and 1,622 nonempty source records. Independent downloads of all 16 matched the frozen
repository bytes. independent-table-checks.csv pairs each new digest with its original digest.

release-additions.csv reproduces the release changelogs: 8,285 public file entries,
including 566 videos by filename. The master document reported 8,285 and 566.
complete-public-file-tree.csv walks the separate versioned inventory returned to NASA's browser:
53,611 leaf entries, 1,244 video entries, 48,659 distinct accession/path/versions,
and 48,590 distinct accession/paths. Entries appearing twice in returned folders are retained.
A ZIP counts as one archive; classifying names does not inspect its members. Only the original
experimental CSV contents are bundled. Access flags and release versions are checked.
archive-summary.json gives extension counts, exact requests, response SHA-256 hashes and
the distinction between release additions and the complete published tree. The historical
team ZIP T5 was unavailable for an independent comparison to that specific file.

Check the package after extracting with shasum -a 256 -c SHA256SUMS.txt.
Rebuild offline: python3 scripts/package_psi_core.py
Repeat the NASA source requests: python3 scripts/package_psi_core.py --refresh
Read inventory.csv for decoding, source locators and row counts. Count each nonempty
logical CSV record following its header once. NASA metadata, flow checks and repeated
settings can produce source records without a separately identifiable test.
