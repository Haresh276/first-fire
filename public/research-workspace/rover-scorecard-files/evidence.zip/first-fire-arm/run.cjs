/* Capture the FIRST FIRE release through its public browser controls. No answer key is read.
   Usage: node run.cjs tasks.json operator-plan.json output-folder [base URL or file: directory URL]
   Each JSON task requires an id and its question. Plans describe operator controls and views. */
'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { performance } = require('node:perf_hooks');
let chromium;
try { ({chromium} = require('playwright')); }
catch { ({chromium} = require(path.join(os.homedir(), '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'))); }
const [bankFile, planFile, outDir, rawBase='https://first-fire-lunar-lab.vercel.app/'] = process.argv.slice(2);
const base = new URL(rawBase.endsWith('/') ? rawBase : rawBase + '/');
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const round = n => Math.round(n);
const save = (filename, data) => fs.writeFile(path.join(outDir, filename), JSON.stringify(data, null, 2)+'\n');

async function answerFromChat(page, task) {
  await page.goto(new URL('index.html#chat',base).href);
  const field = page.locator('#ffchat-question');
  await field.waitFor({state:'visible'});
  const cap = await field.evaluate(e=>e.maxLength);
  if (task.question.length > cap) throw Error('Question exceeds the FIRST FIRE message limit: '+task.id);
  await field.fill(task.question);
  const start = performance.now();
  await field.press('Enter');
  await page.locator('.ffchat-answer-text').first().waitFor({state:'visible', timeout:120000});
  const responseMs = round(performance.now()-start);
  const answer = (await page.locator('.ffchat-answer-text').first().innerText()).trim();
  const sources = await page.locator('.ffchat-reply').first().locator('a[href]').evaluateAll(links =>
    links.map(a=>({label:a.textContent.trim(),href:a.getAttribute('href')})));
  // These are the app's source records exposed in the transcript drawer. The grading focuses on the visible answer and displayed links.
  const turn = await page.evaluate(() => {
    const threads=JSON.parse(sessionStorage.getItem('first-fire.chat.v1') || '{}').threads || [];
    return threads.flatMap(t=>t.turns).at(-1);
  });
  if (!turn || turn.question !== task.question || turn.answer.trim() !== answer) {
    throw Error('Stored and displayed chat response do not agree for '+task.id);
  }
  return {answer, sources, sourceRecords:turn.sources, status:turn.status, responseMs, controlActions:['Type the exact task','Press Enter']};
}

async function downloadFile(page, selector) {
  const next = page.waitForEvent('download');
  await page.locator(selector).click();
  const download = await next;
  const raw = await fs.readFile(await download.path());
  return {raw, value:JSON.parse(raw), filename:download.suggestedFilename()};
}

async function collectInstrument(page, task, plan) {
  const controlActions=[], evidence=[], downloads={};
  await page.goto(new URL(plan.page||'judge-lab.html',base).href);
  await page.locator(plan.ready||'#lab').waitFor({state:'visible'});
  const start = performance.now();
  for (const [stepIndex,action] of plan.steps.entries()) {
    const [method,selector,value,label] = action;
    const control = page.locator(selector);
    if (method==='click') await control.click();
    else if (method==='check') await control.check();
    else if (method==='select') await control.selectOption(value);
    else if (method==='fill') await control.fill(value==='__QUESTION__'?task.question:String(value));
    else if (method==='go') await page.goto(new URL(selector,base).href);
    else if (method==='slider'){
      const [step,current]=await control.evaluate(e=>[Number(e.step),Number(e.value)]);
      const keys=(Number(value)-current)/step;
      if (!Number.isInteger(keys)) throw Error('Time outside the slider step size');
      const key=keys<0?'ArrowLeft':'ArrowRight';
      for(let n=0;n<Math.abs(keys);n++)await control.press(key);
      if(Number(await control.inputValue())!==Number(value))throw Error('Slider target mismatch');
    }
    else if (method==='press') await control.press(value);
    else if (method==='wait') await control.waitFor({state:'visible'});
    else if (method==='read') {
      const text = await control.allInnerTexts();
      evidence.push({step:stepIndex+1,element:selector,label:label||null,text:text.map(s=>s.trim()).join('\n')});
    } else if (method==='links') {
      evidence.push({step:stepIndex+1,element:selector,label:label||null,links:await control.evaluateAll(links => links.map(a=>({text:a.textContent.trim(),href:a.getAttribute('href')})))});
    } else if (method==='download') {
      const file = await downloadFile(page,selector);
      const localName = task.id+'-'+value+'.json'; downloads[value]={...file,localName};
      await fs.writeFile(path.join(outDir,localName),file.raw);
      evidence.push({step:stepIndex+1,filename:localName,sha256:digest(file.raw),label:label||'Original downloaded JSON'});
    } else if (method==='upload') {
      const f=downloads[value];
      if (!f) throw Error('Attempt to replay before downloading an instrument receipt');
      await control.setInputFiles({name:f.filename,mimeType:'application/json',buffer:f.raw});
    } else if (method==='alterFrontAndUpload') {
      const src=downloads[value].value;
      const changed=structuredClone(src);
      if(Math.abs(changed.current.metrics.positionCm-3.4)>1e-6) throw Error('Tamper test needs the 17 s, 2 mm/s genuine record.');
      changed.current.metrics.positionCm=3.8;
      const bytes=Buffer.from(JSON.stringify(changed,null,2)+'\n'), name=task.id+'-altered.json';
      await fs.writeFile(path.join(outDir,name),bytes);
      await control.setInputFiles({name,mimeType:'application/json',buffer:bytes});
      evidence.push({step:stepIndex+1,filename:name,sha256:digest(bytes),label:'Only current.metrics.positionCm was changed, from 3.4 to 3.8 cm'});
    } else if(method==='waitText') {
      await page.waitForFunction(([q,t])=>document.querySelector(q)?.textContent.includes(t),[selector,value]);
    } else throw Error('Unsupported browser action '+method);
    if (!['read','links','wait','waitText'].includes(method)) controlActions.push({method,selector,value:value==='__QUESTION__'?task.question:value??null});
  }
  return {url:page.url(),controlActions,evidence,elapsedMs:round(performance.now()-start)};
}

async function main() {
  if(!bankFile||!planFile||!outDir) throw Error('Supply tasks.json, operator-plan.json and the output directory');
  const [bankBytes,planBytes]=await Promise.all([fs.readFile(bankFile),fs.readFile(planFile)]);
  const plan=JSON.parse(planBytes);
  const tasks=bankFile.endsWith('.txt')?Array.from(bankBytes.toString('utf8').matchAll(/^([QW]\d+)\. (.+)$/gm),m=>({id:m[1],question:m[2]})):JSON.parse(bankBytes);
  if (!tasks.length) throw Error('No frozen tasks found.');
  for(const task of tasks) if(!/^[A-Za-z0-9_-]+$/.test(task.id)||typeof task.question!=='string')throw Error('Invalid task');
  await fs.mkdir(outDir,{recursive:true});
  const browser=await chromium.launch({headless:true});
  const result={system:'FIRST FIRE',baseURL:base.href,createdAt:new Date().toISOString(),bankSHA256:digest(bankBytes),operatorPlanSHA256:digest(planBytes),
    browser:'Chromium '+browser.version(),notes:'An operator converted each frozen task into normal FIRST FIRE instrument actions. Fresh Chromium context per task. Timings measure automated browser actions and are unsuitable for human comparisons. The packet is already encoded in the release.',assetSHA256:{},tasks:[]};
  try {
    for (const task of tasks) {
      const errors=[]; const context=await browser.newContext();
      try {
        const page=await context.newPage(); page.setDefaultTimeout(20000);
        const captureJobs=[];
        page.on('pageerror',e=>errors.push(e.message));
        page.on('response',r=>{
          const u=new URL(r.url()), f=u.pathname.split('/').at(-1);
          if (u.origin===base.origin && /^(judge-(experiment|lab|awareness)\.js|physics-lab\.js|rover-model\.js|chat-ui\.js|science-chat\.js|cases\.json|records\.js)$/.test(f)) {
            captureJobs.push(r.body().then(bytes=>{result.assetSHA256[f]=digest(bytes)}).catch(()=>{}));
          }
        });
        const chat=process.env.FF_EXTRA_CHAT==='1'?await answerFromChat(page,task):null;
        const instrument=plan[task.id]?await collectInstrument(page,task,plan[task.id]):null;
        const row={id:task.id,question:task.question,chat,instrument,pageErrors:errors};
        await save(task.id+'-response.json',row);
        result.tasks.push(row);
        await Promise.allSettled(captureJobs);
        if(errors.length) throw Error('Unexpected page errors for '+task.id+': '+errors.join(' | '));
        console.log(task.id,chat?.status||'instrument',instrument?.controlActions?.length??0,'instrument actions');
      } finally {await context.close();}
    }
  } finally {
    await browser.close();
    await save('run.json',result);
  }
}
main().catch(err=>{console.error(err);process.exitCode=1;});
