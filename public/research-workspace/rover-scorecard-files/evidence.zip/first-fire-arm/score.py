"""Score the 24 frozen checks against the captured releases and native exports."""
from pathlib import Path
import json
import math
import argparse

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--captures', type=Path, default=HERE / 'captured')
parser.add_argument('--output', type=Path, default=HERE / 'grade.json')
args = parser.parse_args()
RUN = args.captures
KEY = json.loads((HERE.parent / 'marking-key.json').read_text())


def load(filename):
    return json.loads((RUN / filename).read_text())


def near(value, target):
    return isinstance(value, (int, float)) and math.isclose(value, target, rel_tol=0, abs_tol=.01)


def shown(task, element):
    return '\n'.join(item.get('text','') for item in load(task+'-response.json')['instrument']['evidence'] if item.get('element') == element)


def block(task, details):
    return {'id':task,'criteria':[{'check':criterion,'passed':bool(pass_),'evidence':evidence,'artifact':file}
        for criterion,(pass_,evidence,file) in zip(KEY[task],details,strict=True)]}


def fields(task):
    return load(task+'-comparison.json')


rows=[]
q=fields('Q1')
rows.append(block('Q1',[(near(n,expected),f'{n:.2f} cm','Q1-comparison.json')
    for n,expected in [(q['baseline']['metrics']['positionCm'],6.66),(q['current']['metrics']['positionCm'],4.81),(q['deltas']['positionCm'],-1.85)]]))
seq=shown('Q2','#measurement')
method=shown('Q2','#pl-comparison p:has(strong)')
records=fields('Q2')['current']['sources']
table=next(r for r in records if r['id']=='PSI-98:1:3')
paper=next(r for r in records if r['id']=='flow-measurement')
rows.append(block('Q2',[
    ('in sequence on one specimen' in seq and 'prior heating or changes to the shared specimen' in method,seq+' '+method,'Q2-response.json'),
    ('fresh matched specimens' in seq and 'counterbalance' in seq,seq,'Q2-response.json'),
    ('CSV records the conditions' in table['boundary'] and 'Slide 21' in paper['locator'] and '20170008805' in paper['url'],table['locator']+' | '+paper['locator'],'Q2-comparison.json')]))
q=fields('Q3')['current']
b=q['boundary']
rows.append(block('Q3',[
    (near(q['metrics']['positionCm'],8),'positionCm = '+str(q['metrics']['positionCm']),'Q3-comparison.json'),
    (q['imposedRate']['kind']=='user-imposed' and q['imposedRate']['sourceRow'] is None,shown('Q3','#claim'),'Q3-comparison.json'),
    ('flight qualification need separate measurements' in b,b,'Q3-comparison.json')]))
q=fields('Q4')['current']
phys=load('Q4-physics.json')['results']['physics']['record']
assert phys['inputs']==q['physicallyModeledInputs'] and phys['seconds']==q['settings']['time']
rows.append(block('Q4',[
    (near(phys['outputs']['burned'],2.25),str(phys['outputs']['burned'])+' g','Q4-physics.json'),
    (near(q['metrics']['chemicalKJ'],97.65),f'{q["metrics"]["chemicalKJ"]:.2f} kJ','Q4-comparison.json'),
    (near(q['metrics']['couponKJ'],434),str(q['metrics']['couponKJ'])+' kJ','Q4-comparison.json')]))
o=load('Q5-open.json')['current']
u=load('Q5-unknown.json')['current']
rows.append(block('Q5',[
    (o['status']=='open-cabin' and o['metrics']['oxygenPct'] is None,'open-cabin | oxygenPct = null','Q5-open.json'),
    (u['status']=='unknown-material' and u['metrics']['chemicalKJ'] is None and u['metrics']['couponKJ'] is None,'unknown-material | chemicalKJ = null | couponKJ = null','Q5-unknown.json'),
    (all(isinstance(item['metrics']['supportN'], (float,int)) for item in [o,u]),f'open deck support {o["metrics"]["supportN"]:.2f} N | unknown material support {u["metrics"]["supportN"]:.2f} N','Q5-response.json')]))
q=fields('Q6');a=q['baseline']['metrics'];b=q['current']['metrics'];method=shown('Q6','.pl-method details[open] p')
rows.append(block('Q6',[
    (near(a['supportN'],2689.2) and near(b['supportN'],6158.6),f'{a["supportN"]:.1f} N; {b["supportN"]:.1f} N','Q6-comparison.json'),
    (near(a['positionCm'],9) and near(b['positionCm'],9),f'{a["positionCm"]} cm; {b["positionCm"]} cm','Q6-comparison.json'),
    ('Surface gravity changes chassis weight' in method and 'chamber balance uses the front speed you enter' in method,method.split('\n')[-1],'Q6-response.json')]))
q=fields('W1');a=q['baseline'];b=q['current'];basis=[(t['imposedRate']['sourceRow'],t['imposedRate']['speedMmS'],t['settings']['flow'])for t in [a,b]]
rows.append(block('W1',[
    (basis==[('PSI-98:1:2',1.8,'concurrent'),('PSI-98:1:3',1.3,'opposed')],str(basis),'W1-comparison.json'),
    (all(t['settings']['time']==37 for t in [a,b]) and q['units']['positionCm']=='cm' and all('speedMmS' in t['imposedRate'] for t in [a,b]),'37 s; imposedRate.speedMmS; units.positionCm = cm','W1-comparison.json'),
    (near(a['metrics']['positionCm'],6.66) and near(b['metrics']['positionCm'],4.81) and near(q['deltas']['positionCm'],-1.85),f'{a["metrics"]["positionCm"]:.2f}, {b["metrics"]["positionCm"]:.2f}, {q["deltas"]["positionCm"]:.2f} cm','W1-comparison.json')]))
ws=[load('W2-'+name+'.json') for name in ['first','altered','second']]
trialv=[(w['current']['imposedRate']['speedMmS'],w['current']['settings']['time'],w['current']['metrics']['positionCm'])for w in ws]
# Verify exactly one field differs between the genuine original and the deliberately edited input.
assert ws[1]['current']['metrics']['positionCm']==3.8
ws[1]['current']['metrics']['positionCm']=ws[0]['current']['metrics']['positionCm']
assert ws[1]==ws[0]
obs=shown('W2','#file-status').splitlines()
assert len(obs)==3
rows.append(block('W2',[(all(near(x,y) for x,y in zip(tup,ex)) and line.startswith(prefix),f'{tup[0]} mm/s, {tup[1]} s, {tup[2]:g} cm. '+line,'W2-response.json')
    for tup,ex,line,prefix in zip(trialv,[(2,17,3.4),(2,17,3.8),(1.3,63,8.19)],obs,['Replay verified','File not applied','Replay verified'],strict=True)]))
n=lambda prefix:sum(r['passed'] for task in rows if task['id'].startswith(prefix) for r in task['criteria'])
result={'system':'FIRST FIRE instrument workspace','science':{'points':n('Q'),'outOf':18},'workflow':{'points':n('W'),'outOf':6},'questions':rows}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('Science',n('Q'),'/ 18; workflow',n('W'),'/ 6')
