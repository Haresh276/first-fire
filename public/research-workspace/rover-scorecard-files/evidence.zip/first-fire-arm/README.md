# FIRST FIRE instrument run

A test operator translated the six science questions and two workflow challenges into actions on the public FIRST FIRE site. Each task began in a new Chromium browser context. The capture includes the exact submitted question, the controls used, displayed text, source links, original download bytes and observed replay verdicts. The operator selected and configured the tools. The product generated the calculations, source labels, exports and replay verdicts.

[Open the criterion-level scores](grade.json) or [inspect the browser capture](captured/run.json). The capture includes the UTC start time, browser version, input hashes, served product asset hashes and per-task errors. Elapsed times measure automated browser operations. The action log groups input operations such as setting a slider into a single entry.

## Independent inspection

| Task | Evidence |
| --- | --- |
| Flow change at 37 s | [Comparison download](captured/Q1-comparison.json) |
| Confounding and next experiment | [Visible methods text](captured/Q2-response.json) and [source locators](captured/Q2-comparison.json) |
| User-imposed 2 mm/s at 40 s | [Run, provenance and qualification limits](captured/Q3-comparison.json) |
| PE coupon at 50 s | [Energy](captured/Q4-comparison.json) and [exact consumed mass](captured/Q4-physics.json) |
| Open cabin and unknown material | [Open-deck output](captured/Q5-open.json) and [unknown-material output](captured/Q5-unknown.json) |
| Moon and Mars | [Both support loads and travel distances](captured/Q6-comparison.json) and [model explanation](captured/Q6-response.json) |
| Portable 37 s comparison | [Native JSON](captured/W1-comparison.json) |
| Replay challenge | [Three observed verdicts](captured/W2-response.json), [first genuine file](captured/W2-first.json), [edited file](captured/W2-altered.json), [second genuine file](captured/W2-second.json) |

For the PE question, the operator opened the separate chamber physics instrument, matched the judge lab’s physically modeled inputs and exported its result. The chamber display rounds consumed mass to 2.3 g. Its native data record contains 2.25 g. The scorer checks equality of the input sets and simulated times across both downloads.

For the replay challenge, the test changes only the current recorded front position from 3.4 to 3.8 cm before re-import. The scorer checks that restoring that value makes the edited JSON structurally identical to the original.

## Reproduce

Use Node.js with Playwright and its Chromium browser, plus Python 3.10 or newer. From this folder, capture to a new directory, then score those bytes against the shared rubric.

```sh
node run.cjs ../shared-prompt.txt operator-plan.json /tmp/first-fire-rerun https://first-fire-lunar-lab.vercel.app/
python3 score.py --captures /tmp/first-fire-rerun --output /tmp/first-fire-rerun/grade.json
```

The reader can compare the served asset hashes to determine whether a rerun used the same product build. The capture runner reads the task packet and the operator plan. Only the separate scorer loads the marking key.
