'use strict';
// Run from this folder. Only the reviewed original arithmetic function may run.
const fs = require('node:fs'), crypto = require('node:crypto'), vm = require('node:vm'), assert = require('node:assert/strict');
const path = require('node:path');
const base = __dirname, arm = path.join(base,'chatgpt-arm');
const load = (name) => JSON.parse(fs.readFileSync(path.join(arm,name),'utf8'));
const response = load('observed.json'), rawCode = fs.readFileSync(path.join(arm,'returned-validator.js'),'utf8');
const digest = s => crypto.createHash('sha256').update(s).digest('hex');
assert.equal(digest(rawCode),'b2a55e56e3ffc68434bbcbb332bc5f2d22de99c861bcf0fb3aa948f10994b287');
assert.equal(response.validator,rawCode);
assert.equal(response.prompt.trimEnd(),fs.readFileSync(path.join(base,'shared-prompt.txt'),'utf8').trimEnd());
const record = load('returned-record.json');
assert.equal(response.record, fs.readFileSync(path.join(arm,'returned-record.json'),'utf8'));
const equal = (a,b) => typeof a === 'number' && Math.abs(a-b) < 0.000001;
const paired = [
 record.baseline.row_id==='PSI-98:1:2' && equal(record.baseline.rate_mm_s,1.8) && record.baseline.direction==='concurrent' && record.current.row_id==='PSI-98:1:3' && equal(record.current.rate_mm_s,1.3) && record.current.direction==='opposed',
 record.time_s===37 && record.rate_unit==='mm/s' && record.distance_unit==='cm',
 equal(record.baseline.distance_cm,6.66) && equal(record.current.distance_cm,4.81) && equal(record.difference.signed_distance_cm,-1.85) && record.difference.definition==='current_minus_baseline'
];
const env=vm.createContext({console:{log(){}}},{codeGeneration:{strings:false,wasm:false}});
vm.runInContext(rawCode,env,{timeout:100});
const probe=(rateMmS,timeS,travelCm,expected)=>{
 const actual=vm.runInContext('valid('+[rateMmS,timeS,travelCm].join(',')+')',env,{timeout:100});
 return {rateMmS,timeS,travelCm,expected,actual,passed:expected===actual};
};
const probes=[probe(2,17,3.4,true),probe(2,17,3.8,false),probe(1.3,63,8.19,true)];
const result={recordChecks:paired,validatorChecks:probes,workflowPoints:paired.filter(Boolean).length+probes.filter(p=>p.passed).length,outOf:6,validatorSHA256:digest(rawCode)};
fs.writeFileSync(path.join(arm,'executed-checks.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
