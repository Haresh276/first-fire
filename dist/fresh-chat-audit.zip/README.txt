FIRST FIRE local chat evaluations

A: previous release and compact local repair on first sealed bank. B: compact repair and stronger local synthesis on a second unseen bank. Open each report.json for exact scores, predictions, failures and comparisons. SHA256SUMS identifies all original files. questions.json contains prompts only; rubric.json is the independently sealed grading key. Numbers are local research benchmark results. Reproduction instructions are in chat/README.md in the FIRST FIRE repository.
