"""Prepare a masked, deduplicated work queue or join independent semantic judgments.
Input JSON list of {ticket, id, answer, citations}, or JSONL. No model or track ids used.
Usage: python3 grade.py prepare responses.json queue.json
       python3 grade.py score responses.json decisions.json grades.json
Reviewer decisions: {key, content, grounded, material_error, reason, code}.
"""
import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

def read(path):
    raw=Path(path).read_text()
    try: return json.loads(raw)
    except json.JSONDecodeError: return [json.loads(line) for line in raw.splitlines() if line.strip()]

def write(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, ensure_ascii=False)+'\n')

def digest(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(',',':')).encode()).hexdigest()

def source_signature(c):
    if isinstance(c,str): return c
    # Retain anything that affects what the user saw, except transient transport or confidence fields.
    return {k:v for k,v in c.items() if k not in {'confidence','latency','duration','score','similarity'}}

def queue(data, questions, rubrics):
    if not isinstance(data,list) or not data: raise ValueError('Expected a nonempty array of masked responses')
    bykey={}; refs={}
    for row in data:
        item=row['id']; answer=row['answer']; citations=row.get('citations',[])
        if item not in questions or not isinstance(answer,str) or not isinstance(citations,list):
            raise ValueError('Malformed response '+str(item))
        sig={'id':item,'answer':answer.strip(),'citations':[source_signature(c) for c in citations]}
        key=digest(sig)
        if row['ticket'] in refs: raise ValueError('Duplicate ticket')
        refs[row['ticket']]=key
        if key not in bykey:
            bykey[key]={'key':key,'id':item,'question':questions[item],'expected':rubrics[item]['expected'],
                        'behavior':rubrics[item]['behavior'],'source_options':rubrics[item]['source_options'],
                        'answer':sig['answer'],'citations':sig['citations']}
    ordered=sorted(bykey.values(),key=lambda q:(q['id'],q['key']))
    return ordered,refs

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('mode',choices=['prepare','score']); ap.add_argument('inputs'); ap.add_argument('decisions_or_output'); ap.add_argument('output',nargs='?')
    ap.add_argument('--bank-dir',default=str(Path(__file__).resolve().parent)); args=ap.parse_args(); base=Path(args.bank_dir)
    seal=read(base/'seal.json')
    for f in ('questions.json','rubric.json'):
        if hashlib.sha256((base/f).read_bytes()).hexdigest()!=seal['files'][f]: raise ValueError('Sealed file drift '+f)
    questions={q['id']:q['message'] for q in read(base/'questions.json')['questions']}
    rb=read(base/'rubric.json'); rubrics={q['id']:q for q in rb['rubrics']}
    q,refs=queue(read(args.inputs),questions,rubrics)
    if args.mode=='prepare':
        write(args.decisions_or_output,q)
        print(f'{len(refs)} masked tickets; {len(q)} unique rendered question/answer/citation sets.')
        return
    decisions=read(args.decisions_or_output)
    if not isinstance(decisions,list): raise ValueError('Expected reviewer decision array')
    decisions_by_key={d['key']:d for d in decisions}
    if len(decisions_by_key)!=len(decisions) or set(decisions_by_key)!=set(refs.values()): raise ValueError('Missing, duplicate or extraneous grading key')
    legal=set(rb['grading']['failure_codes']); grades=[]
    for row in read(args.inputs):
        ticket=row['ticket']; key=refs[ticket]; d=decisions_by_key[key]
        if any(type(d[k]) is not bool for k in ('content','grounded','material_error')): raise ValueError('Nonboolean decision flags')
        passed=d['content'] and d['grounded'] and not d['material_error']
        if d['code'] not in legal or passed!=(d['code']=='pass') or not d['reason'].strip(): raise ValueError('Inconsistent judgment '+str(d))
        grades.append(dict(ticket=ticket,id=row['id'],key=key,passed=passed,**{k:d[k] for k in ('content','grounded','material_error','code','reason')}))
    write(args.output,grades)
    print('Masked responses by primary code',dict(Counter(g['code'] for g in grades)))

if __name__=='__main__':main()

